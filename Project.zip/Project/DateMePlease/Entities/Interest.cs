﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DateMePlease.Entities
{
  public class Interest
  {
    public int Id { get; set; }

    public InterestType InterestType { get; set; }

  }
}
