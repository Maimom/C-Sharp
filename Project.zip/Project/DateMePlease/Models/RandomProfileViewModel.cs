﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DateMePlease.Models
{
  public class RandomProfileViewModel
  {
    public string PhotoUrl { get; set; }

    public string LookingFor { get; set; }

    public string MemberName { get; set; }
  }
}
