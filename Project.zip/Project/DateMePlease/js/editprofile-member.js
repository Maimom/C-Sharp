﻿// editprofile-member.js
$(function () {
  $(".date").datetimepicker({
    useCurrent: false,
    format: 'MM/DD/YYYY'
  });
});
